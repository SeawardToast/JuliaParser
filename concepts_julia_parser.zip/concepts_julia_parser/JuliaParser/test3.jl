function w ( )
r = 5
while <= r 10
print ( r )
 r = + r 1
end
print ( 89 )
end