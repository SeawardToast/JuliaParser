function a ( )
  for i = 3 : 5
  if != i 4
  print ( i )
  else
  print ( 333 )
  end 
  end
  end
  